// SteamClouds button injection (standalone plugin)
(function() {
    'use strict';

    function backendLog(message) {
        try {
            if (typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                Millennium.callServerMethod('SteamClouds', 'Logger.warn', { message: String(message) });
            }
        } catch (err) {
            if (typeof console !== 'undefined' && console.warn) {
                console.warn('[SteamClouds] backendLog failed', err);
            }
        }
    }

    backendLog('SteamClouds script loaded');
    const logState = { missingOnce: false, existsOnce: false };
    const runState = { inProgress: false, appid: null };

    function showTestPopup() {
        if (document.querySelector('.SteamClouds-overlay')) return;

        const overlay = document.createElement('div');
        overlay.className = 'SteamClouds-overlay';
        overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.6);z-index:99999;display:flex;align-items:center;justify-content:center;';

        const modal = document.createElement('div');
        modal.style.cssText = 'background:#1b2838;color:#fff;border:1px solid #2a475e;border-radius:4px;min-width:340px;max-width:560px;padding:18px 20px;box-shadow:0 8px 24px rgba(0,0,0,.6);';

        const title = document.createElement('div');
        title.style.cssText = 'font-size:16px;color:#66c0f4;margin-bottom:10px;font-weight:600;';
        title.className = 'SteamClouds-title';
        title.textContent = 'SteamClouds';

        const body = document.createElement('div');
        body.style.cssText = 'font-size:14px;line-height:1.4;margin-bottom:12px;';
        body.className = 'SteamClouds-status';
        body.textContent = 'Working…';

        const progressWrap = document.createElement('div');
        progressWrap.style.cssText = 'background:#2a475e;height:10px;border-radius:4px;overflow:hidden;position:relative;display:none;';
        progressWrap.className = 'SteamClouds-progress-wrap';
        const progressBar = document.createElement('div');
        progressBar.style.cssText = 'height:100%;width:0%;background:#66c0f4;transition:width 0.1s linear;';
        progressBar.className = 'SteamClouds-progress-bar';
        progressWrap.appendChild(progressBar);

        const percent = document.createElement('div');
        percent.style.cssText = 'text-align:right;color:#8f98a0;margin-top:8px;font-size:12px;display:none;';
        percent.className = 'SteamClouds-percent';
        percent.textContent = '0%';

        const btnRow = document.createElement('div');
        btnRow.style.cssText = 'margin-top:16px;display:flex;gap:8px;justify-content:flex-end;';
        const closeBtn = document.createElement('a');
        closeBtn.className = 'btnv6_blue_hoverfade btn_medium';
        closeBtn.innerHTML = '<span>Close</span>';
        closeBtn.href = '#';
        closeBtn.onclick = function(e){ e.preventDefault(); cleanup(); };
        btnRow.appendChild(closeBtn);

        modal.appendChild(title);
        modal.appendChild(body);
        modal.appendChild(progressWrap);
        modal.appendChild(percent);
        modal.appendChild(btnRow);
        overlay.appendChild(modal);
        overlay.addEventListener('click', function(e){ if (e.target === overlay) cleanup(); });
        document.body.appendChild(overlay);

        function cleanup(){
            overlay.remove();
        }
    }

    function ensureStyles() {
        if (!document.getElementById('SteamClouds-styles')) {
            const style = document.createElement('style');
            style.id = 'SteamClouds-styles';
            style.textContent = '.SteamClouds-restart-button, .SteamClouds-button{ margin-left:6px !important; } .SteamClouds-installed-label{ margin-left:10px;color:#67c1f5;font-weight:700; }';
            document.head.appendChild(style);
        }
    }

    function addSteamCloudsButton() {
        const steamdbContainer = document.querySelector('.steamdb-buttons') ||
                                 document.querySelector('[data-steamdb-buttons]') ||
                                 document.querySelector('.apphub_OtherSiteInfo');

        if (!steamdbContainer) {
            if (!logState.missingOnce) { backendLog('SteamClouds: steamdbContainer not found on this page'); logState.missingOnce = true; }
            return;
        }

        if (document.querySelector('.SteamClouds-button') || window.__SteamCloudsButtonInserted) {
            if (!logState.existsOnce) { backendLog('SteamClouds button already exists, skipping'); logState.existsOnce = true; }
            return;
        }

        let referenceBtn = steamdbContainer.querySelector('a');
        const SteamCloudsButton = document.createElement('a');
        SteamCloudsButton.href = '#';
        SteamCloudsButton.className = (referenceBtn && referenceBtn.className) ? (referenceBtn.className + ' SteamClouds-button') : 'btnv6_blue_hoverfade btn_medium SteamClouds-button';
        const span = document.createElement('span');
        span.textContent = 'Add Games';
        SteamCloudsButton.appendChild(span);

        SteamCloudsButton.title = 'Add Games';
        SteamCloudsButton.setAttribute('data-tooltip-text', 'Add Games');

        try {
            if (referenceBtn) {
                const cs = window.getComputedStyle(referenceBtn);
                SteamCloudsButton.style.marginLeft = cs.marginLeft;
                SteamCloudsButton.style.marginRight = cs.marginRight;
            }
        } catch(_) {}

        SteamCloudsButton.addEventListener('click', function(e) {
            e.preventDefault();
            backendLog('SteamClouds button clicked (delegated handler will process)');
        });

        try {
            const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
            const appid = match ? parseInt(match[1], 10) : NaN;
            if (!isNaN(appid) && typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                if (window.__SteamCloudsPresenceCheckInFlight && window.__SteamCloudsPresenceCheckAppId === appid) {
                    return;
                }
                window.__SteamCloudsPresenceCheckInFlight = true;
                window.__SteamCloudsPresenceCheckAppId = appid;
                Millennium.callServerMethod('SteamClouds', 'HasSteamCloudsForApp', { appid, contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        if (payload && payload.success && payload.exists === true) {
                            backendLog('SteamClouds already present for this app; skip Add button (already added)');
                            window.__SteamCloudsPresenceCheckInFlight = false;
                            return;
                        }

                        if (!document.querySelector('.SteamClouds-button') && !window.__SteamCloudsButtonInserted) {
                            const restartExisting = steamdbContainer.querySelector('.SteamClouds-restart-button');
                            if (restartExisting && restartExisting.parentElement) {
                                restartExisting.parentElement.insertBefore(SteamCloudsButton, restartExisting);
                            } else if (referenceBtn && referenceBtn.parentElement) {
                                if (referenceBtn.nextSibling) {
                                    referenceBtn.parentElement.insertBefore(SteamCloudsButton, referenceBtn.nextSibling);
                                } else {
                                    referenceBtn.parentElement.appendChild(SteamCloudsButton);
                                }
                            } else {
                                steamdbContainer.appendChild(SteamCloudsButton);
                            }
                            window.__SteamCloudsButtonInserted = true;
                            backendLog('SteamClouds button inserted');
                        }
                        window.__SteamCloudsPresenceCheckInFlight = false;
                    } catch(_) {
                        if (!document.querySelector('.SteamClouds-button') && !window.__SteamCloudsButtonInserted) {
                            steamdbContainer.appendChild(SteamCloudsButton);
                            window.__SteamCloudsButtonInserted = true;
                            backendLog('SteamClouds button inserted');
                        }
                        window.__SteamCloudsPresenceCheckInFlight = false;
                    }
                });
            } else {
                if (!document.querySelector('.SteamClouds-button') && !window.__SteamCloudsButtonInserted) {
                    const restartExisting = steamdbContainer.querySelector('.SteamClouds-restart-button');
                    if (restartExisting && restartExisting.parentElement) {
                        restartExisting.parentElement.insertBefore(SteamCloudsButton, restartExisting);
                    } else if (referenceBtn && referenceBtn.parentElement) {
                        if (referenceBtn.nextSibling) {
                            referenceBtn.parentElement.insertBefore(SteamCloudsButton, referenceBtn.nextSibling);
                        } else {
                            referenceBtn.parentElement.appendChild(SteamCloudsButton);
                        }
                    } else {
                        steamdbContainer.appendChild(SteamCloudsButton);
                    }
                    window.__SteamCloudsButtonInserted = true;
                    backendLog('SteamClouds button inserted');
                }
            }
        } catch(_) {
            if (!document.querySelector('.SteamClouds-button') && !window.__SteamCloudsButtonInserted) {
                const restartExisting = steamdbContainer.querySelector('.SteamClouds-restart-button');
                if (restartExisting && restartExisting.parentElement) {
                    restartExisting.parentElement.insertBefore(SteamCloudsButton, restartExisting);
                } else if (referenceBtn && referenceBtn.parentElement) {
                    if (referenceBtn.nextSibling) {
                        referenceBtn.parentElement.insertBefore(SteamCloudsButton, referenceBtn.nextSibling);
                    } else {
                        referenceBtn.parentElement.appendChild(SteamCloudsButton);
                    }
                } else {
                    steamdbContainer.appendChild(SteamCloudsButton);
                }
                window.__SteamCloudsButtonInserted = true;
                backendLog('SteamClouds button inserted');
            }
        }
    }

    function onFrontendReady() {
        try {
            if (localStorage.getItem('SteamClouds_installed') === 'true') {
                const steamdbContainer = document.querySelector('.steamdb-buttons') ||
                                         document.querySelector('[data-steamdb-buttons]') ||
                                         document.querySelector('.apphub_OtherSiteInfo');

                if (steamdbContainer && !document.querySelector('.SteamClouds-installed-label')) {
                    const installedLabel = document.createElement('span');
                    installedLabel.className = 'SteamClouds-installed-label';
                    installedLabel.style.cssText = 'margin-left:10px;color:#67c1f5;font-weight:bold;';
                    installedLabel.textContent = '✔ Added to library';
                    steamdbContainer.appendChild(installedLabel);
                }
            }
        } catch(_) {}
        ensureStyles()
        addSteamCloudsButton();
        try {
            if (typeof Millennium !== 'undefined' && typeof Millennium.callServerMethod === 'function') {
                Millennium.callServerMethod('SteamClouds', 'GetInitApisMessage', { contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        if (payload && payload.message) {
                            if (typeof ShowAlertDialog === 'function') {
                                ShowAlertDialog('SteamClouds', String(payload.message));
                            } else {
                                backendLog('InitApis queued message: ' + payload.message);
                            }
                        }
                    } catch(_){ }
                });
            }
        } catch(_) { }
    }


    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', onFrontendReady);
    } else {
        onFrontendReady();
    }

    document.addEventListener('click', function(evt) {
        const anchor = evt.target && (evt.target.closest ? evt.target.closest('.SteamClouds-button') : null);
        if (!anchor) return;

        evt.preventDefault();

        const mode = anchor.dataset.mode || "add";
        const match = window.location.href.match(/https:\/\/store\.steampowered\.com\/app\/(\d+)/) || window.location.href.match(/https:\/\/steamcommunity\.com\/app\/(\d+)/);
        const appid = match ? parseInt(match[1], 10) : NaN;
        if (isNaN(appid)) return;

        if (runState.inProgress && runState.appid === appid) {
            backendLog('Looks like Steam Cloud is still syncing this game ☁️. Hang tight—it’ll be ready soon');
            return;
        }

        if (mode === "remove") {
            backendLog('SteamClouds delegated click (REMOVE mode)');
            const doConfirm = function() {
                Millennium.callServerMethod('SteamClouds', 'RemoveSteamCloudsForApp', { appid, contentScriptQuery: '' })
                .then(function(res){
                    const payload = (typeof res === 'string') ? JSON.parse(res) : res;
                    if (payload && payload.success) {
                        const msg = payload.message || '✅ Game removed. Please restart Steam to refresh your Library.';
                        if (typeof ShowAlertDialog === 'function') ShowAlertDialog('SteamClouds', msg);
                        else alert(msg);

                        try { anchor.querySelector('span').textContent = 'Add Games'; } catch(_) {}
                        try { anchor.title = 'Add Games'; anchor.setAttribute('data-tooltip-text', 'Add Games'); anchor.dataset.mode = "add"; } catch(_) {}

                        // remove installed label + restart button if present
                        try {
                            const lbl = document.querySelector('.SteamClouds-installed-label');
                            if (lbl && lbl.parentElement) lbl.parentElement.removeChild(lbl);
                        } catch(_) {}
                        try {
                            const rbtn = document.querySelector('.SteamClouds-restart-button');
                            if (rbtn && rbtn.parentElement) rbtn.parentElement.removeChild(rbtn);
                        } catch(_) {}
                    } else {
                        const err = (payload && payload.error) || 'Remove failed';
                        if (typeof ShowAlertDialog === 'function') ShowAlertDialog('SteamClouds', '⚠️ ' + err);
                        else alert('⚠️ ' + err);
                    }
                })
                .catch(function(err){
                    backendLog('Remove call failed: ' + err);
                    alert('⚠️ Remove failed: ' + err);
                });
            };

            if (typeof ShowConfirmDialog === 'function') {
                const p = ShowConfirmDialog('SteamClouds', '❌ Remove this game from your Library?');
                if (p && typeof p.then === 'function') p.then(doConfirm);
            } else {
                if (window.confirm('❌ Remove this game from your Library?')) doConfirm();
            }

            return;
        }

        // ADD mode
        backendLog('SteamClouds delegated click (ADD mode)');
        if (!document.querySelector('.SteamClouds-overlay')) showTestPopup();

        runState.inProgress = true;
        runState.appid = appid;
        try {
            Millennium.callServerMethod('SteamClouds', 'StartAddViaSteamClouds', { appid, contentScriptQuery: '' });
        } catch(_) {}
        startPolling(appid);
    }, true);


    function startPolling(appid){
        const overlay = document.querySelector('.SteamClouds-overlay');
        if (!overlay) return;
        const percent = overlay.querySelector('.SteamClouds-percent');
        const bar = overlay.querySelector('.SteamClouds-progress-bar');
        const title = overlay.querySelector('.SteamClouds-title');
        const status = overlay.querySelector('.SteamClouds-status');
        const wrap = overlay.querySelector('.SteamClouds-progress-wrap');
        let done = false;

        const timer = setInterval(() => {
            if (done) { clearInterval(timer); return; }
            if (!overlay || !overlay.isConnected) { clearInterval(timer); return; }
            try {
                Millennium.callServerMethod('SteamClouds', 'GetAddViaSteamCloudsStatus', { appid, contentScriptQuery: '' }).then(function(res){
                    try {
                        const payload = typeof res === 'string' ? JSON.parse(res) : res;
                        const st = payload && payload.state ? payload.state : {};

                        if (st.currentApi && title) title.textContent = 'SteamClouds · ' + st.currentApi;

                        if (status) {
                            if (st.status === 'checking') status.textContent = 'Just a moment — we’re checking what’s ready for you 😊';
                            if (st.status === 'downloading') status.textContent = '🚀 Getting things ready…';
                            if (st.status === 'processing') status.textContent = '⏳ Almost there… just processing';
                            if (st.status === 'installing') status.textContent = '⏳ Almost done — installing now…';
                            if (st.status === 'done') status.textContent = '⚙️ Finalizing configs…';
                            if (st.status === 'failed') status.textContent = 'Oops! Installation didn’t complete 😓';
                        }

                        if (st.status === 'downloading'){
                            if (wrap && wrap.style.display === 'none') wrap.style.display = 'block';
                            if (percent && percent.style.display === 'none') percent.style.display = 'block';
                            const total = st.totalBytes || 0; const read = st.bytesRead || 0;
                            let pct = total > 0 ? Math.floor((read/total)*100) : (read ? 1 : 0);
                            if (pct > 100) pct = 100; if (pct < 0) pct = 0;
                            if (bar) bar.style.width = pct + '%';
                            if (percent) percent.textContent = pct + '%';
                        }

                        if (st.status === 'done') {
                            if (bar) bar.style.width = '100%';
                            if (percent) percent.textContent = '100%';
                            if (status) status.textContent = '🎉 Game successfully added.\nPlease restart Steam to view it in your Library.🚀';
                            const btn = overlay.querySelector('.btnv6_blue_hoverfade.btn_medium');
                            if (btn) btn.innerHTML = '<span>Done</span>';
                            setTimeout(function(){
                                if (wrap) wrap.style.display = 'none';
                                if (percent) percent.style.display = 'none';
                            }, 300);

                            done = true;
                            clearInterval(timer);
                            runState.inProgress = false;
                            runState.appid = null;



                            try {
                                const addBtn = document.querySelector('.SteamClouds-button');
                                if (addBtn) {
                                    addBtn.outerHTML = '<span class="SteamClouds-installed-label" ' +
                                        'style="margin-left:10px;color:#67c1f5;font-weight:bold;">✔ Added to library</span>';
                                }
                            } catch(_) {}

                            try {
                                const steamdbContainer = document.querySelector('.steamdb-buttons') ||
                                                         document.querySelector('[data-steamdb-buttons]') ||
                                                         document.querySelector('.apphub_OtherSiteInfo');

                                if (steamdbContainer) {
                                    if (!document.querySelector('.SteamClouds-installed-label')) {
                                        const installedLabel = document.createElement('span');
                                        installedLabel.className = 'SteamClouds-installed-label';
                                        installedLabel.textContent = '✔ Added to library';
                                        steamdbContainer.appendChild(installedLabel);
                                    }

                                    if (!document.querySelector('.SteamClouds-restart-button')) {
                                        const ref = steamdbContainer.querySelector('a');
                                        const restartBtn = document.createElement('a');
                                        restartBtn.href = '#';
                                        restartBtn.className = (ref && ref.className)
                                            ? (ref.className + ' SteamClouds-restart-button')
                                            : 'btnv6_blue_hoverfade btn_medium SteamClouds-restart-button';
                                        restartBtn.title = 'Restart Steam';
                                        restartBtn.setAttribute('data-tooltip-text', 'Restart Steam');
                                        const rspan = document.createElement('span');
                                        rspan.textContent = 'Restart Steam';
                                        restartBtn.appendChild(rspan);

                                        restartBtn.addEventListener('click', function(e){
                                            e.preventDefault();
                                            try {
                                                if (typeof ShowConfirmDialog === 'function') {
                                                    const p = ShowConfirmDialog('SteamClouds', '🔄 Ready to restart Steam and refresh your Library?');
                                                    if (p && typeof p.then === 'function') {
                                                        p.then(function(){
                                                            try { Millennium.callServerMethod('SteamClouds', 'RestartSteam', { contentScriptQuery: '' }); } catch(_) {}
                                                        });
                                                    }
                                                } else {
                                                    if (window.confirm('🔄 Ready to restart Steam and refresh your Library?')) {
                                                        try { Millennium.callServerMethod('SteamClouds', 'RestartSteam', { contentScriptQuery: '' }); } catch(_) {}
                                                    }
                                                }
                                            } catch(_) {}
                                        });

                                        steamdbContainer.appendChild(restartBtn);
                                    }
                                }
                            } catch(_) {}
                        }

                        if (st.status === 'failed'){
                            if (status) status.textContent = 'Failed: ' + (st.error || 'Unknown error');
                            const btn = overlay.querySelector('.btnv6_blue_hoverfade.btn_medium');
                            if (btn) btn.innerHTML = '<span>Close</span>';
                            if (wrap) wrap.style.display = 'none'; if (percent) percent.style.display = 'none';
                            done = true; clearInterval(timer);
                            runState.inProgress = false; runState.appid = null;
                        }
                    } catch(_){ }
                });
            } catch(_){ clearInterval(timer); }
        }, 300);
    }

    setTimeout(addSteamCloudsButton, 1000);
    setTimeout(addSteamCloudsButton, 3000);

    // Use MutationObserver to catch dynamically added content
    if (typeof MutationObserver !== 'undefined') {
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    addSteamCloudsButton();
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }
})();
