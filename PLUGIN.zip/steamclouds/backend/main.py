import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests
import httpx

try:
    import Millennium
except Exception:
    Millennium = None

try:
    import PluginUtils
    logger = PluginUtils.Logger()
except Exception:
    class _DummyLogger:
        def log(self, m: str) -> None:
            print(f"[LOG] {m}")
        def warn(self, m: str) -> None:
            print(f"[WARN] {m}")
        def error(self, m: str) -> None:
            print(f"[ERROR] {m}")
    logger = _DummyLogger()

WEBKIT_DIR_NAME = "SteamClouds"
WEB_UI_JS_FILE = "SteamClouds.js"
API_URL = "https://extension.steamdb.info/api"
API_MANIFEST_URL = "https://raw.githubusercontent.com/gregetmaxs/sc_api_links/refs/heads/main/load_apis"
API_JSON_FILE = "api.json"

DEFAULT_HEADERS = {
    "Accept": "application/json",
    "X-Requested-With": "SteamDB",
    "User-Agent": "https://github.com/BossSloth/Steam-SteamDB-extension",
    "Origin": "https://github.com/BossSloth/Steam-SteamDB-extension",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
}

HTTP_CLIENT: Optional[httpx.Client] = None
APIS_INIT_DONE = False
INIT_APIS_LAST_MESSAGE = ""
DOWNLOAD_STATE: Dict[int, Dict[str, Any]] = {}
DOWNLOAD_LOCK = threading.Lock()
STEAM_INSTALL_PATH: Optional[str] = None

class Logger:
    @staticmethod
    def info(*args, **kwargs) -> None:
        try:
            msg = Logger._extract_msg(*args, **kwargs)
            logger.log(msg)
        except Exception:
            try:
                logger.log(str(args or kwargs))
            except Exception:
                pass

    @staticmethod
    def success(msg: str) -> None:
        try:
            logger.log(f"✅ {msg}")
        except Exception:
            print(f"✅ {msg}")

    @staticmethod
    def warn(*args, **kwargs) -> None:
        try:
            msg = Logger._extract_msg(*args, **kwargs)
            logger.warn(msg)
        except TypeError:
            try:
                logger.log(msg)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    def error(*args, **kwargs) -> None:
        try:
            msg = Logger._extract_msg(*args, **kwargs)
            logger.error(msg)
        except TypeError:
            try:
                logger.log(msg)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    def _extract_msg(*args, **kwargs) -> str:
        if "message" in kwargs and kwargs["message"] is not None:
            return str(kwargs["message"])
        if args:
            first = args[0]
            try:
                return str(first)
            except Exception:
                return json.dumps(first, default=str)
        return ""

def GetPluginDir() -> str:
    return os.path.abspath(os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", ".."))

def _backend_path(filename: str) -> str:
    return os.path.join(GetPluginDir(), "backend", filename)

def _read_text(path: str) -> str:
    try:
        with open(path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception:
        return ""

def _write_text(path: str, text: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

def _count_apis(text: str) -> int:
    try:
        data = json.loads(text)
        apis = data.get("api_list", [])
        if isinstance(apis, list):
            return len(apis)
    except Exception:
        pass
    return text.count('"name"')

def init_http_client() -> None:
    global HTTP_CLIENT
    if HTTP_CLIENT is not None:
        return
    try:
        Logger.info("Initializing HTTPX client...")
        HTTP_CLIENT = httpx.Client(timeout=20.0)
        Logger.success("HTTPX client ready.")
    except Exception as e:
        HTTP_CLIENT = None
        Logger.warn(f"Failed to initialize HTTPX client: {e} — falling back to requests.")

def _ensure_http_client_module() -> None:
    init_http_client()

def _normalize_manifest_text(text: str) -> str:
    s = (text or "").strip()
    if not s:
        return ""
    s = re.sub(r",\s*([\]\}])", r"\1", s)
    try:
        parsed = json.loads(s)
        if isinstance(parsed, list):
            return json.dumps({"api_list": parsed}, ensure_ascii=False)
        if isinstance(parsed, dict) and "api_list" in parsed:
            return json.dumps(parsed, ensure_ascii=False)
        return s
    except Exception:
        if s.lstrip().startswith('"api_list"') or s.lstrip().startswith("'api_list'") or s.lstrip().startswith("api_list"):
            if not s.lstrip().startswith("{"):
                s = "{" + s
            if not s.rstrip().endswith("}"):
                s = s.rstrip(", ") + "}"
            try:
                json.loads(s)
                return s
            except Exception:
                pass
    return s

def InitApis_module() -> str:
    global APIS_INIT_DONE, HTTP_CLIENT, INIT_APIS_LAST_MESSAGE
    Logger.info("InitApis (module) invoked")
    if APIS_INIT_DONE:
        Logger.info("InitApis (module): already done this session")
        return json.dumps({"success": True, "message": INIT_APIS_LAST_MESSAGE})
    _ensure_http_client_module()
    api_json_path = _backend_path(API_JSON_FILE)
    message = ""
    if os.path.exists(api_json_path):
        Logger.info(f"Local api.json exists: {api_json_path} — skipping remote fetch")
    else:
        Logger.info("Local api.json not found — attempting to fetch free manifest")
        manifest_text = ""
        try:
            if HTTP_CLIENT is not None:
                resp = HTTP_CLIENT.get(API_MANIFEST_URL)
                resp.raise_for_status()
                manifest_text = resp.text
                Logger.info(f"Fetched manifest (len={len(manifest_text)})")
            else:
                resp = requests.get(API_MANIFEST_URL, timeout=15)
                resp.raise_for_status()
                manifest_text = resp.text
                Logger.info("Fetched manifest via requests fallback")
        except Exception as e:
            Logger.warn(f"Failed to fetch manifest: {e}")
        norm = _normalize_manifest_text(manifest_text) if manifest_text else ""
        if norm:
            try:
                _write_text(api_json_path, norm)
                count = _count_apis(norm)
                message = f"No API's Configured — loaded {count} free ones 🎉"
                Logger.success(f"Wrote api.json with {count} entries")
            except Exception as e:
                message = "Failed to write api.json"
                Logger.error(f"Failed to write api.json: {e}")
        else:
            message = "No API's Configured and failed to load free ones"
            Logger.warn("Manifest empty or not usable")
    APIS_INIT_DONE = True
    INIT_APIS_LAST_MESSAGE = message
    Logger.info(f"InitApis (module) done: {message}")
    return json.dumps({"success": True, "message": message})

def _load_api_manifest() -> List[Dict[str, Any]]:
    path = _backend_path(API_JSON_FILE)
    txt = _read_text(path)
    if not txt:
        Logger.warn("No api.json present")
        return []
    norm = _normalize_manifest_text(txt)
    if norm and norm != txt:
        try:
            _write_text(path, norm)
            Logger.info("Normalized and saved api.json")
        except Exception:
            Logger.warn("Failed to normalize api.json (saving)")
    try:
        data = json.loads(norm or txt)
        apis = data.get("api_list", []) if isinstance(data, dict) else []
        enabled = [a for a in apis if a.get("enabled", False)]
        Logger.info(f"Loaded {len(enabled)} enabled API(s) from manifest")
        return enabled
    except Exception as e:
        Logger.error(f"Failed to parse api.json: {e}")
        return []

def detect_steam_install_path() -> str:
    global STEAM_INSTALL_PATH
    if STEAM_INSTALL_PATH:
        return STEAM_INSTALL_PATH
    candidates = []
    try:
        import winreg
        candidates = [
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam", "InstallPath"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam", "InstallPath"),
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam", "SteamPath"),
        ]
        for hive, subkey, name in candidates:
            try:
                with winreg.OpenKey(hive, subkey) as key:
                    val = winreg.QueryValueEx(key, name)[0]
                    if val:
                        path = os.path.normpath(os.path.abspath(val))
                        STEAM_INSTALL_PATH = path
                        Logger.info(f"Detected Steam path from registry: {path}")
                        return path
            except Exception:
                continue
    except Exception:
        Logger.warn("winreg not available — skipping registry checks")
    try:
        if Millennium is not None and hasattr(Millennium, "steam_path"):
            path = Millennium.steam_path()
            if path:
                path = os.path.normpath(os.path.abspath(path))
                STEAM_INSTALL_PATH = path
                Logger.info(f"Using Millennium.steam_path() as fallback: {path}")
                return path
    except Exception as e:
        Logger.warn(f"Millennium.steam_path() fallback failed: {e}")
    pf86 = os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")
    fallback = os.path.normpath(os.path.join(pf86, "Steam"))
    STEAM_INSTALL_PATH = fallback
    Logger.warn(f"Falling back to default Steam path: {fallback}")
    return fallback

def copy_webkit_files() -> None:
    try:
        plugin_js = os.path.join(GetPluginDir(), "public", WEB_UI_JS_FILE)
        steam_base = detect_steam_install_path() or ""
        if not steam_base:
            Logger.warn("Steam base path unknown — cannot copy web UI")
            return
        steam_ui_dir = os.path.join(steam_base, "steamui", WEBKIT_DIR_NAME)
        os.makedirs(steam_ui_dir, exist_ok=True)
        dest = os.path.join(steam_ui_dir, WEB_UI_JS_FILE)
        Logger.info(f"Copying {plugin_js} -> {dest}")
        try:
            shutil.copy2(plugin_js, dest)
            Logger.success("Copied SteamClouds web UI JS")
        except Exception as e:
            Logger.error(f"Failed to copy web UI JS: {e}")
    except Exception as e:
        Logger.error(f"copy_webkit_files failed: {e}")

def inject_webkit_files() -> None:
    try:
        jsPath = os.path.join(WEBKIT_DIR_NAME, WEB_UI_JS_FILE)
        if Millennium is not None and hasattr(Millennium, "add_browser_js"):
            Millennium.add_browser_js(jsPath)
            Logger.info(f"Injected web UI script: {jsPath}")
        else:
            Logger.warn("Millennium.add_browser_js not available — skipping injection")
    except Exception as e:
        Logger.error(f"inject_webkit_files error: {e}")


def RestartSteam(contentScriptQuery: str = '') -> str:
    """Run the pre-shipped restart_steam.cmd in backend/. No generation, just execute."""
    backend_dir = os.path.join(GetPluginDir(), 'backend')
    script_path = os.path.join(backend_dir, 'restart_steam.cmd')
    if not os.path.exists(script_path):
        logger.error(f'SteamClouds: restart script not found: {script_path}')
        return json.dumps({'success': False, 'error': 'restart_steam.cmd not found'})
    try:
        # Menggunakan STARTUPINFO untuk menyembunyikan jendela
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0  # Menyembunyikan jendela

        subprocess.Popen(['cmd', '/C', script_path], startupinfo=startupinfo)
        logger.log('SteamClouds: Restart script launched (hidden window)')
        return json.dumps({'success': True})
    except Exception as e:
        logger.error(f'SteamClouds: Failed to launch restart script: {e}')
        return json.dumps({'success': False, 'error': str(e)})


def _set_download_state(appid: int, update: Dict[str, Any]) -> None:
    with DOWNLOAD_LOCK:
        state = DOWNLOAD_STATE.get(appid, {}).copy()
        state.update(update)
        DOWNLOAD_STATE[appid] = state

def _get_download_state(appid: int) -> Dict[str, Any]:
    with DOWNLOAD_LOCK:
        return DOWNLOAD_STATE.get(appid, {}).copy()

def _process_and_install_lua(appid: int, zip_path: str) -> None:
    base = detect_steam_install_path() or (Millennium.steam_path() if Millennium else "")
    target_dir = os.path.join(base or "", "config", "stplug-in")
    os.makedirs(target_dir, exist_ok=True)
    Logger.info(f"Processing zip for {appid}: {zip_path}")
    with zipfile.ZipFile(zip_path, "r") as zf:
        names = zf.namelist()
        candidates = [n for n in names if re.fullmatch(r".*?/(\d+\.lua)|(\d+\.lua)$", n) or re.fullmatch(r"\d+\.lua", os.path.basename(n))]
        numeric_candidates = [n for n in names if re.fullmatch(r".*?(\d+\.lua)$", n) or re.fullmatch(r"\d+\.lua", os.path.basename(n))]
        if not candidates:
            candidates = numeric_candidates
        chosen = None
        preferred = f"{appid}.lua"
        for n in candidates:
            if os.path.basename(n) == preferred:
                chosen = n
                break
        if not chosen and candidates:
            chosen = candidates[0]
        if not chosen:
            raise RuntimeError("We couldn’t find any numeric .lua file inside the zip 🤷‍♂️")
        raw = zf.read(chosen)
        try:
            txt = raw.decode("utf-8")
        except Exception:
            txt = raw.decode("utf-8", errors="replace")
        lines: List[str] = []
        for line in txt.splitlines(True):
            if re.match(r"^\s*setManifestid\s*\(", line) and not re.match(r"^\s*--", line):
                m = re.match(r"^(\s*)", line)
                indent = m.group(1) if m else ""
                lines.append(f"{indent}--{line.lstrip()}")
            else:
                lines.append(line)
        processed = "".join(lines)
        _set_download_state(appid, {"status": "installing"})
        dest_file = os.path.join(target_dir, f"{appid}.lua")
        with open(dest_file, "w", encoding="utf-8") as out:
            out.write(processed)
        Logger.success(f"Installed files to {dest_file}")
        _set_download_state(appid, {"installedPath": dest_file})

def _download_zip_for_app(appid: int) -> None:
    _ensure_http_client_module()
    apis = _load_api_manifest()
    if not apis:
        Logger.warn("We couldn’t connect to any database right now 😕")
        _set_download_state(appid, {"status": "failed", "error": "We couldn’t connect to any database right now 😕"})
        return
    dest_path = _backend_path(f"{appid}.zip")
    _set_download_state(appid, {"status": "checking", "currentApi": None, "bytesRead": 0, "totalBytes": 0, "dest": dest_path})
    for api in apis:
        name = api.get("name", "unknown")
        template = api.get("url", "")
        success_code = int(api.get("success_code", 200))
        unavailable_code = int(api.get("unavailable_code", 404))
        url = template.replace("<appid>", str(appid))
        _set_download_state(appid, {"status": "checking", "currentApi": name, "bytesRead": 0, "totalBytes": 0})
        Logger.info(f"Trying '{name}' -> {url}")
        try:
            if HTTP_CLIENT is not None:
                with HTTP_CLIENT.stream("GET", url, follow_redirects=True, headers=DEFAULT_HEADERS) as resp:
                    code = resp.status_code
                    Logger.info(f"Database - '{name}' returned {code}")
                    if code == unavailable_code:
                        continue
                    if code != success_code:
                        continue
                    total = int(resp.headers.get("Content-Length", "0") or "0")
                    _set_download_state(appid, {"status": "downloading", "bytesRead": 0, "totalBytes": total})
                    with open(dest_path, "wb") as f:
                        for chunk in resp.iter_bytes():
                            if not chunk:
                                continue
                            f.write(chunk)
                            st = _get_download_state(appid)
                            read = int(st.get("bytesRead", 0)) + len(chunk)
                            _set_download_state(appid, {"bytesRead": read})
            else:
                with requests.get(url, stream=True, headers=DEFAULT_HEADERS, timeout=30) as resp:
                    code = resp.status_code
                    Logger.info(f"(requests) Database - '{name}' returned {code}")
                    if code == unavailable_code:
                        continue
                    if code != success_code:
                        continue
                    total = int(resp.headers.get("Content-Length", "0") or "0")
                    _set_download_state(appid, {"status": "downloading", "bytesRead": 0, "totalBytes": total})
                    with open(dest_path, "wb") as f:
                        for chunk in resp.iter_content(chunk_size=8192):
                            if not chunk:
                                continue
                            f.write(chunk)
                            st = _get_download_state(appid)
                            read = int(st.get("bytesRead", 0)) + len(chunk)
                            _set_download_state(appid, {"bytesRead": read})
            Logger.success(f"Download complete -> {dest_path}")
            try:
                _set_download_state(appid, {"status": "processing"})
                _process_and_install_lua(appid, dest_path)
                _set_download_state(appid, {"status": "done", "success": True, "api": name})
            except Exception as e:
                Logger.warn(f"Processing failed: {e}")
                _set_download_state(appid, {"status": "failed", "error": f"Processing failed: {e}"})
            return
        except Exception as e:
            Logger.warn(f"API '{name}' attempt failed: {e}")
            continue
    _set_download_state(appid, {"status": "failed", "error": "We couldn’t find this in any of our databases 🤷‍♂️"})

def StartAddViaSteamClouds(appid: int, contentScriptQuery: str = "") -> str:
    try:
        appid_int = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Hmm... that AppID doesn’t seem valid 🤔"})
    Logger.info(f"SteamClouds is preparing your file for AppID {appid_int} 🚀")
    _set_download_state(appid_int, {"status": "queued", "bytesRead": 0, "totalBytes": 0})
    t = threading.Thread(target=_download_zip_for_app, args=(appid_int,), daemon=True)
    t.start()
    return json.dumps({"success": True})

def GetAddViaSteamCloudsStatus(appid: int, contentScriptQuery: str = "") -> str:
    try:
        appid_int = int(appid)
    except Exception:
        return json.dumps({"success": False, "error": "Hmm... that AppID doesn’t seem valid 🤔"})
    state = _get_download_state(appid_int)
    return json.dumps({"success": True, "state": state})

class Plugin:
    def init_http_client(self) -> None:
        init_http_client()
    def close_http_client(self) -> None:
        global HTTP_CLIENT
        if HTTP_CLIENT:
            try:
                HTTP_CLIENT.close()
            except Exception:
                pass
            HTTP_CLIENT = None
            Logger.info("Closed HTTP client")
    def _get_backend_path(self, filename: str) -> str:
        return _backend_path(filename)
    def _read_text(self, p: str) -> str:
        return _read_text(p)
    def _write_text(self, p: str, text: str) -> None:
        _write_text(p, text)
    def _count_apis(self, text: str) -> int:
        return _count_apis(text)
    def InitApis(self, contentScriptQuery: str = "") -> str:
        return InitApis_module()
    def GetInitApisMessage(self, contentScriptQuery: str = "") -> str:
        global INIT_APIS_LAST_MESSAGE
        msg = INIT_APIS_LAST_MESSAGE or ""
        INIT_APIS_LAST_MESSAGE = ""
        return json.dumps({"success": True, "message": msg})
    def copy_webkit_files(self) -> None:
        copy_webkit_files()
    def inject_webkit_files(self) -> None:
        inject_webkit_files()
    def _front_end_loaded(self) -> None:
        self.copy_webkit_files()
    def _load(self) -> None:
        Logger.info(f"Bootstrapping SteamClouds plugin — Millennium version: {getattr(Millennium, 'version', lambda: 'unknown')()}")
        try:
            detect_steam_install_path()
        except Exception as e:
            Logger.warn(f"Steam path detection failed at boot: {e}")
        self.init_http_client()
        try:
            self.copy_webkit_files()
            self.inject_webkit_files()
        except Exception as e:
            Logger.warn(f"copy/inject webkit files encountered an error: {e}")
        try:
            res = self.InitApis("boot")
            Logger.info(f"InitApis (boot) returned: {res}")
        except Exception as e:
            Logger.error(f"InitApis (boot) failed: {e}")
        try:
            if Millennium is not None and hasattr(Millennium, "ready"):
                Millennium.ready()
        except Exception:
            pass
    def _unload(self) -> None:
        Logger.info("Unloading SteamClouds backend")
        self.close_http_client()

def HasSteamCloudsForApp(appid, contentScriptQuery=''):
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({'success': False, 'error': 'Invalid appid'})
    try:
        base = ''
        try:
            base = detect_steam_install_path()
        except Exception:
            base = None
        try:
            if not base and Millennium is not None and hasattr(Millennium, "steam_path"):
                base = Millennium.steam_path()
        except Exception:
            base = base or ''
        if not base:
            return json.dumps({'success': False, 'error': 'Steam path not found'})
        candidate1 = os.path.join(base, 'config', 'stplug-in', f'{appid}.lua')
        candidate2 = os.path.join(base, 'config', 'stplug-in', f'{appid}.lua.disabled')
        exists = os.path.exists(candidate1) or os.path.exists(candidate2)
        return json.dumps({'success': True, 'exists': bool(exists)})
    except Exception as e:
        return json.dumps({'success': False, 'error': str(e)})

InitApis = InitApis_module
GetInitApisMessage = lambda contentScriptQuery="": (json.dumps({"success": True, "message": (INIT_APIS_LAST_MESSAGE and (lambda: (globals().update({"INIT_APIS_LAST_MESSAGE": ""}) or "") )())}) if True else json.dumps({"success": True, "message": ""}))



def RemoveSteamCloudsForApp(appid, contentScriptQuery=''):
    """
    Hapus konfigurasi SteamClouds untuk `appid`.
    Tidak mematikan Steam — hanya menghapus file .lua (atau .lua.disabled).
    User diminta untuk restart Steam agar perubahan terlihat.
    """
    try:
        appid = int(appid)
    except Exception:
        return json.dumps({'success': False, 'error': 'Invalid appid'})

    try:
        base = ''
        try:
            base = detect_steam_install_path()
        except Exception:
            base = None
        try:
            if not base and Millennium is not None and hasattr(Millennium, "steam_path"):
                base = Millennium.steam_path()
        except Exception:
            base = base or ''

        if not base:
            return json.dumps({'success': False, 'error': 'Steam path not found'})

        candidates = [
            os.path.join(base, 'config', 'stplug-in'),
            os.path.join(base, 'config', 'stplugins'),
            os.path.join(base, 'config', 'st-plugin'),
            os.path.join(base, 'plugins'),
        ]

        removed_any = False
        errors = []

        for cand in candidates:
            try:
                if not os.path.exists(cand):
                    continue
                if os.path.basename(cand).lower() == 'plugins':
                    for entry in os.listdir(cand):
                        p = os.path.join(cand, entry)
                        if not os.path.isdir(p):
                            continue
                        target = os.path.join(p, f"{appid}.lua")
                        if os.path.exists(target):
                            try:
                                disabled = target + ".disabled"
                                if os.path.exists(disabled):
                                    os.remove(disabled)
                                os.rename(target, disabled)
                                Logger.success(f"Renamed {target} -> {disabled}")
                                removed_any = True
                            except Exception as e:
                                errors.append(str(e))
                else:
                    target = os.path.join(cand, f"{appid}.lua")
                    if os.path.exists(target):
                        try:
                            disabled = target + ".disabled"
                            if os.path.exists(disabled):
                                os.remove(disabled)
                            os.rename(target, disabled)
                            Logger.success(f"Renamed {target} -> {disabled}")
                            removed_any = True
                        except Exception as e:
                            errors.append(str(e))
            except Exception as e:
                errors.append(str(e))

        try:
            manifest_path = os.path.join(base, "steamapps", f"appmanifest_{appid}.acf")
            if os.path.exists(manifest_path):
                try:
                    os.remove(manifest_path)
                    Logger.success(f"Removed manifest {manifest_path}")
                    removed_any = True
                except Exception as e:
                    errors.append(f"manifest:{str(e)}")
        except Exception:
            pass

        if removed_any:
            return json.dumps({
                'success': True,
                'removed': True,
                'errors': errors,
                'message': '✅ Game successfully removed. Please restart Steam to refresh your Library.'
            })
        else:
            return json.dumps({
                'success': False,
                'error': 'No Games files found for this appid',
                'errors': errors,
                'message': '⚠️ No Games files found for this AppID.'
            })
    except Exception as e:
        Logger.error(f"RemoveSteamCloudsForApp failed: {e}")
        return json.dumps({'success': False, 'error': str(e)})
